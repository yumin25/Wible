-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j6a303.p.ssafy.io    Database: wibledb
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_seq` int NOT NULL AUTO_INCREMENT,
  `user_seq` int NOT NULL,
  `wine_seq` int NOT NULL,
  `review_text` varchar(255) NOT NULL,
  `review_score` double NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`review_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,3,1,'리뷰 수정',3.9,'2022-03-18 01:47:32'),(2,1,1,'굿굿',3,'2022-03-22 08:27:28'),(3,1,4,'평범해요',5,'2022-03-23 02:48:55'),(4,1,4,'좋아요',9,'2022-03-23 02:49:44'),(6,1,4,'가나다라마바사아자차카타파하가나다라마바사아자차카타파하가나다라마바사아자차카타파하세글자',10,'2022-03-23 04:13:55'),(7,1,4,'가나다라마바사아자차카타파하가나다라마바사아자차카타파하가나다라마바사아자차카타파하글자를더',10,'2022-03-23 04:16:17'),(8,1,4,'가나다라마바사아자차카타파하가나다라마바사아자차카타파하가나다라마바사아자차카타파하글자한',10,'2022-03-23 04:17:03'),(9,1,4,'ㅎㅎㅎㅎㅎ',10,'2022-03-23 05:38:37'),(10,1,4,'ㄱㄱㄱㄱㄱ',10,'2022-03-23 05:38:41'),(11,1,4,'ㄴㄴㄴㄴ',10,'2022-03-23 05:38:42'),(12,1,4,'ㄷㄷㄷㄷ',10,'2022-03-23 05:38:44'),(13,1,4,'ㄹㄹㄹㄹㄹ',10,'2022-03-23 05:38:45'),(14,1,4,'ㅇㅇㅇㅇㅇ',10,'2022-03-23 05:38:46'),(15,1,4,'ㅋㅋ',6,'2022-03-23 05:42:36'),(16,1,4,'?',5,'2022-03-23 05:45:19'),(17,1,4,'test',1,'2022-03-23 05:46:00'),(24,9,1,'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz',10,'2022-03-25 07:21:34'),(25,9,5,'?',10,'2022-03-25 07:21:45'),(26,9,3,'gggg',10,'2022-03-25 07:21:57'),(27,9,4,'gkgk',3,'2022-03-25 07:22:25'),(28,9,2,'????',10,'2022-03-25 07:22:33'),(29,10,51,'이 와인 쩔어여',10,'2022-03-28 08:39:25'),(30,0,1563,'aa',10,'2022-03-29 07:14:24'),(31,0,1768,'tt',10,'2022-04-03 11:21:23'),(32,13,2240,'저렴한 가격에 비해 맛이 고급스럽습니다!!',8,'2022-04-07 00:57:30'),(33,13,1409,'비싼데 그 값어치를 합니다!! 생일 같이 특별한 날 드시면 좋을 것 같아요!',10,'2022-04-07 00:58:32'),(34,13,1967,'달달하고 맛있네요!',8,'2022-04-07 04:04:41'),(35,16,18,'바디감이 묵직합니다! 추천합니다 맛있어요',8,'2022-04-07 04:10:03'),(36,13,1601,'가성비 좋은 와인입니다.',6,'2022-04-07 04:20:33'),(37,13,1539,'내 인생 샴페인...진짜...',10,'2022-04-07 04:21:04'),(38,13,1204,'좋아요!',7,'2022-04-07 06:15:58');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:20:31
