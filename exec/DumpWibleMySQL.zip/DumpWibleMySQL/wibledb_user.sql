-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: j6a303.p.ssafy.io    Database: wibledb
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'toramx5@gmail.com','$2a$10$ij3aooepUSir15roAkT1pupqMHaF1lZEq.P38vnGG5R3ljma7VYMm','테스트123456751213','가나다','010-7890-7890','2022-03-21 05:38:29','2022-03-21 05:38:29'),(7,'jamie1541@naver.com','$2a$10$J4syyMZH3TrgP.Lc8TWxBuGWIql5Pu/MNht9TlZePlDxuZuDaUjC.','ddd','z','010-0000-0000','2022-03-21 07:54:46','2022-03-21 07:54:46'),(8,'jamie1541@naver.com','$2a$10$UILwXaJ2QttD0ZtZFRr73u7CByoJVTyJsMHR90CYGVbkMGvLF/o/K','ddd','z','010-0000-0000','2022-03-21 07:58:42','2022-03-21 07:58:42'),(9,'jamie@naver.com','$2a$10$mRSdCC5tCKhBv8TmsowqseKxnxxafV8Ry.WfAp1rPBbaF1bOsNOzW','닉네임','김수민','010-2222-2222','2022-03-24 13:48:14','2022-03-24 13:48:14'),(10,'gud_ejr@naver.com','$2a$10$ZVBg8zOYpAkIf9jPnTtAoOyw8n./u5XqrWfXIDvEblqXSOwEo/bLK','닉네이임','김싸피','01050901279','2022-03-25 01:25:05','2022-03-25 01:25:05'),(12,'kimssafy@ssafy.com','$2a$10$YpkpT.LzOq0u1.ROkvlci.GMObpw325ea7Eqx3lNFCiZSWiR./NDm','김싸피','김싸피','010-7777-9999','2022-03-29 04:47:33','2022-03-29 04:47:33'),(13,'wible@ssafy.com','$2a$10$aKjFMqZruuMARKyMaGuOHOpyItbIr7O5JH2Lnx0QTpTELsYF.5UVq','사용자1','사용자','010-4444-4444','2022-04-05 01:32:14','2022-04-05 01:32:14'),(14,'ssafy@ssafy.com','$2a$10$PIflmWxEEoFyWgFnOwvxf.YOmN0GNlcOgW8DgPuKa1s9bjKchXb5a','싸피짱','김싸피','010-1234-5678','2022-04-05 04:33:30','2022-04-05 04:33:30'),(15,'qwer1234@wible.com','$2a$10$8DlmrP/VSFewXLOMx4qCle0vCBu0vxJ/DaNo1KYFe5DtSdSHAp/XG','라마바사','가나다','010-1234-5698','2022-04-07 01:21:10','2022-04-07 01:21:10'),(16,'wine@naver.com','$2a$10$xVOQ22DepdIjtZNToFRhruCT07nhnQkZbmvZCKFUBlYvGFYOMyCJG','와인와인','김와인','010-4892-4827','2022-04-07 04:08:00','2022-04-07 04:08:00');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-08 11:20:32
